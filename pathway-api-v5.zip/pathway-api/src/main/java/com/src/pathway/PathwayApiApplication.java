package com.src.pathway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({ "com.src.pathway.*" })
public class PathwayApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(PathwayApiApplication.class, args);
	}
}