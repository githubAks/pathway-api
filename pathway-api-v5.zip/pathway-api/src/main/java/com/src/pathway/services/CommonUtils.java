package com.src.pathway.services;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.src.pathway.models.Token;

@Service
public class CommonUtils {
	
	@Value("${external.accessToken.url}")
	String tokenApiUrl;
	
	public Token getToken(){
		RestTemplate restTemplate = new RestTemplate();
		Token token = restTemplate.getForObject(tokenApiUrl, Token.class);
		System.out.println("::token::" + token);
		return token;
	}
}
