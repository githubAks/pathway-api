package com.src.pathway.services;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.src.pathway.models.Catalog;
import com.src.pathway.models.Result;
import com.src.pathway.models.Token;
import com.src.pathway.repositories.CatalogRepository;

@Service
public class CatalogService {
	
	@Value("${external.catalog.api.url}")
	String catalogApiUrl;
	
	@Autowired
	private MongoTemplate mongoTemplate;
	
	@Autowired
	private CatalogRepository catalogRepository;
	
	@Autowired
	private CommonUtils commonUtils;

	/**
	 * 
	 * @return
	 */
	public ResponseEntity<Catalog> getCatalog(){
		
		ResponseEntity<Catalog> response = null;
		
		try {
			Token token = commonUtils.getToken();
			
			System.out.println(token.getAccess_token() + "::access_token::");
			
			HttpHeaders headers = new HttpHeaders();
			headers.set("Authorization", "Bearer " + token.getAccess_token());
			
			HashMap<String, String> requestBody = new HashMap<>();
			requestBody.put("managedByGroups", "NIIT-TEST-001");
			
			HttpEntity requestEntity = new HttpEntity<>(requestBody, headers);
	
			RestTemplate restTemplate = new RestTemplate();		
			response = restTemplate.exchange(catalogApiUrl, HttpMethod.POST, requestEntity, Catalog.class);
		}catch(Exception ex) {
			ex.printStackTrace();
		}
		try{
			//Insert response in mongo
			for(Result result : response.getBody().getResult()){
				System.out.println("::find catalogGuid::" + result.getCatalogGuid());
				if(result.getCatalogGuid() != null){
					Query query = new Query(Criteria.where("catalogGuid").is(result.getCatalogGuid()));
					//Update update = new Update().set("result" , result).set("tm", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
					if(!mongoTemplate.exists(query, "lo_objects")) {
						System.out.println("::Going to insert::");
						mongoTemplate.insert(result);
					}else {
						mongoTemplate.findAndReplace(query, result);
						System.out.println("::Going to findAndReplace::");
					}
					System.out.println("::upsert done::");
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return response;
	}

	/**
	 * 
	 * @param queryParam
	 * @return
	 */
	public List<Object> getCatalogByFilterCriteria(String queryParam) {
		return catalogRepository.getCatalogByFilterCriteria(queryParam);
	}
}
