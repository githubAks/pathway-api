package com.src.pathway.repositories;

import org.springframework.stereotype.Repository;

@Repository
public class UserRepository {

}
