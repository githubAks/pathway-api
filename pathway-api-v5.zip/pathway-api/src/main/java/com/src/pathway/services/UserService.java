package com.src.pathway.services;

import org.springframework.stereotype.Service;

@Service
public class UserService {

}
