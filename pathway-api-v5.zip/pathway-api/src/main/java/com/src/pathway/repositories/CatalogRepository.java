package com.src.pathway.repositories;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import com.src.pathway.models.Catalog;

@Repository("catalogRepository")
public interface CatalogRepository extends MongoRepository<Catalog, String>{

	@Query("?0")
	public List<Object> getCatalogByFilterCriteria(String queryParam);
}