package com.src.pathway.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.src.pathway.models.Catalog;
import com.src.pathway.services.CatalogService;


@EnableMongoRepositories(basePackages={"com.src.pathway.repositories"})
@RestController
public class CatalogController {
	
	@Autowired
	private CatalogService catalogService;
	
	@GetMapping(value = "/getCatalog")
	public ResponseEntity<Catalog> getCatalog(){
		ResponseEntity<Catalog> response = catalogService.getCatalog();
		return ResponseEntity.ok(response.getBody());
	}
	
	@PostMapping(value = "/getCatalogByFilterCriteria")
	public List<Object> getCatalogByFilterCriteria(@RequestBody String queryParam){
		System.out.println("::queryParam::" + queryParam);
		return catalogService.getCatalogByFilterCriteria(queryParam);
	}
}