package com.src.pathway.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.src.pathway.models.Token;
import com.src.pathway.models.transcript.Result;
import com.src.pathway.models.transcript.Transcript;
import com.src.pathway.repositories.TranscriptRepository;

@Service
public class TranscriptService {

	@Value("${external.transcipt.api.url}")
	String transcriptApiUrl;

	@Autowired
	private MongoTemplate mongoTemplate;

	@Autowired
	private TranscriptRepository transcriptRepository;

	@Autowired
	private CommonUtils commonUtils;

	public Transcript getTranscript() {

		Token token = commonUtils.getToken();

		System.out.println(token.getAccess_token() + "::access_token::");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization", "Bearer " + token.getAccess_token());

		MultiValueMap<String, String> body = new LinkedMultiValueMap<>();

		HttpEntity<MultiValueMap<String, String>> requestEntity = new HttpEntity<>(body, headers);

		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<Transcript> response = restTemplate.exchange(transcriptApiUrl, HttpMethod.POST, requestEntity,
				Transcript.class);
		try {
			// Insert response in mongo
			for (Result result : response.getBody().getResult()) {
				if (result.getCatalogGuid() != null) {
					Query query = new Query(Criteria.where("transcriptGuid").is(result.transcriptGuid));
					if (!mongoTemplate.exists(query, "transcript_xfer")) {
						System.out.println("::Going to insert::");
						mongoTemplate.insert(result);
					} else {
						mongoTemplate.findAndReplace(query, result);
						System.out.println("::Going to findAndReplace::");
					}
					System.out.println("::upsert done::");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return response.getBody();
	}

	public List<Object> getCatalogByFilterCriteria(String queryParam) {
		return transcriptRepository.getTranscriptByFilterCriteria(queryParam);
	}

}
