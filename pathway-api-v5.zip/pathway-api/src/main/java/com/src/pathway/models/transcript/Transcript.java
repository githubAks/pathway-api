package com.src.pathway.models.transcript;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "transcript_xfer")
public class Transcript {	
	public List<Result> result;

	public List<Result> getResult() {
		return result;
	}

	public void setResult(List<Result> result) {
		this.result = result;
	}
}
