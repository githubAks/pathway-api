package com.src.pathway.models;

import java.util.ArrayList;

import org.springframework.data.mongodb.core.mapping.Document;

//lombok
@Document(collection = "lo_objects")
public class Catalog {
	// import com.fasterxml.jackson.databind.ObjectMapper; // version 2.11.1
	// import com.fasterxml.jackson.annotation.JsonProperty; // version 2.11.1
	/* ObjectMapper om = new ObjectMapper();
	Root root = om.readValue(myJsonString, Root.class); */
	
	public Catalog(){}
	
	public ArrayList<Result> result;

	public ArrayList<Result> getResult() {
		return result;
	}

	public void setResult(ArrayList<Result> result) {
		this.result = result;
	}
}

class Content{
	
	public Content(){}
	
	private String contentUri;

	public String getContentUri() {
		return contentUri;
	}

	public void setContentUri(String contentUri) {
		this.contentUri = contentUri;
	}
}

class Format{
	
	public Format(){}
	
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
 }

class Image{
	
	public Image(){}
	
	private String uri;
	private String alt;
	public String getUri() {
		return uri;
	}
	public void setUri(String uri) {
		this.uri = uri;
	}
	public String getAlt() {
		return alt;
	}
	public void setAlt(String alt) {
		this.alt = alt;
	}
}

class Provider{
	
	public Provider(){}
	
	private String displayName;

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
}

class RatingCounts{
	
	public RatingCounts(){}
	
    private String rating;
    private String count;
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
}