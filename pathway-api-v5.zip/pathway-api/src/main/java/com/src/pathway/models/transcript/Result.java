package com.src.pathway.models.transcript;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "transcript_xfer")
public class Result {
	public String _id;
	
	@Field("_mid")
    public String transcriptGuid;
    public String tenantGuid;
    public String catalogGuid;
    public String userGuid;
    public String status;
    public String dateOfCompletion;
    public String progress;
    
    public Result() {}
    
	public String get_id() {
		return _id;
	}
	public void set_id(String _id) {
		this._id = _id;
	}
	public String getTranscriptGuid() {
		return transcriptGuid;
	}
	public void setTranscriptGuid(String transcriptGuid) {
		this.transcriptGuid = transcriptGuid;
	}
	public String getTenantGuid() {
		return tenantGuid;
	}
	public void setTenantGuid(String tenantGuid) {
		this.tenantGuid = tenantGuid;
	}
	public String getCatalogGuid() {
		return catalogGuid;
	}
	public void setCatalogGuid(String catalogGuid) {
		this.catalogGuid = catalogGuid;
	}
	public String getUserGuid() {
		return userGuid;
	}
	public void setUserGuid(String userGuid) {
		this.userGuid = userGuid;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDateOfCompletion() {
		return dateOfCompletion;
	}
	public void setDateOfCompletion(String dateOfCompletion) {
		this.dateOfCompletion = dateOfCompletion;
	}
	public String getProgress() {
		return progress;
	}
	public void setProgress(String progress) {
		this.progress = progress;
	}
}
   
   