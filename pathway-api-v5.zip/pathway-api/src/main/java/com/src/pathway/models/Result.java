package com.src.pathway.models;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "lo_objects")
public class Result{
	
	private String catalogGuid;
	
	@Field("_mid")
    private String _id;
	
	private String tenantGuid;
	private String title;
	private String description;
	private Image image;
	private String duration;
	private Provider provider;
	private Format format;
	private String courseLevels;
	private RatingCounts ratingCounts;
	private Content content;
	private String languageFilter;
	private String managedByGroups;
    
    
	public String get_id() {
		return _id;
	}
	public void set_id(String _id) {
		this._id = _id;
	}
	public String getTenantGuid() {
		return tenantGuid;
	}
	public void setTenantGuid(String tenantGuid) {
		this.tenantGuid = tenantGuid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Image getImage() {
		return image;
	}
	public void setImage(Image image) {
		this.image = image;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public Provider getProvider() {
		return provider;
	}
	public void setProvider(Provider provider) {
		this.provider = provider;
	}
	public Format getFormat() {
		return format;
	}
	public void setFormat(Format format) {
		this.format = format;
	}
	public String getCourseLevels() {
		return courseLevels;
	}
	public void setCourseLevels(String courseLevels) {
		this.courseLevels = courseLevels;
	}
	public RatingCounts getRatingCounts() {
		return ratingCounts;
	}
	public void setRatingCounts(RatingCounts ratingCounts) {
		this.ratingCounts = ratingCounts;
	}
	public Content getContent() {
		return content;
	}
	public void setContent(Content content) {
		this.content = content;
	}
	public String getLanguageFilter() {
		return languageFilter;
	}
	public void setLanguageFilter(String languageFilter) {
		this.languageFilter = languageFilter;
	}
	public String getManagedByGroups() {
		return managedByGroups;
	}
	public void setManagedByGroups(String managedByGroups) {
		this.managedByGroups = managedByGroups;
	}
	public String getCatalogGuid() {
		return catalogGuid;
	}
	public void setCatalogGuid(String catalogGuid) {
		this.catalogGuid = catalogGuid;
	}
	
	public Result(){}
}