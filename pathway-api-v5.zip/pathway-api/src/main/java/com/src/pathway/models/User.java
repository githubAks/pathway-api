package com.src.pathway.models;

public class User {

}
