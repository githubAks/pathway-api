package com.src.pathway.controllers;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.src.pathway.models.transcript.Transcript;
import com.src.pathway.services.TranscriptService;

@RestController
public class TranscriptController {
	
	@Autowired
	private TranscriptService transcriptService;

	@GetMapping(value="/getTranscript")
	public ResponseEntity<Transcript> getALLTranscript(){
		Transcript response = transcriptService.getTranscript();
		if(Objects.isNull(response)) {
			
			System.out.println("No Transcript List ");
			return new ResponseEntity<>(response, HttpStatus.NO_CONTENT);
		}
		System.out.println("All Transcript List");
		return new ResponseEntity<>(response, HttpStatus.OK);

	}
	
	@PostMapping(value = "/getTranscriptByFilterCriteria")
	public List<Object> getTranscriptByFilterCriteria(@RequestBody String queryParam){
		System.out.println("::queryParam::" + queryParam);
		return transcriptService.getCatalogByFilterCriteria(queryParam);
	}

}
